import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: cors })

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
  const authHeader = req.headers.get('Authorization')

  if (!authHeader?.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Authentication required' }), { status: 401, headers: { ...cors, 'Content-Type': 'application/json' } })
  }

  const token = authHeader.replace('Bearer ', '')
  const adminClient = createClient(supabaseUrl, serviceRoleKey)
  const callerClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: `Bearer ${token}` } } })

  const { data: callerData, error: callerError } = await callerClient.auth.getUser()
  if (callerError || !callerData.user?.email) {
    return new Response(JSON.stringify({ error: 'Invalid login session' }), { status: 401, headers: { ...cors, 'Content-Type': 'application/json' } })
  }

  const { data: platformAdmin, error: platformError } = await adminClient
    .from('platform_admins')
    .select('id, status')
    .ilike('email', callerData.user.email)
    .eq('status', 'active')
    .maybeSingle()

  if (platformError || !platformAdmin) {
    return new Response(JSON.stringify({ error: 'Only Super Admin can create schools' }), { status: 403, headers: { ...cors, 'Content-Type': 'application/json' } })
  }

  const body = await req.json()
  const required = ['name', 'admin_name', 'email', 'password']
  for (const key of required) {
    if (!body[key] || String(body[key]).trim() === '') {
      return new Response(JSON.stringify({ error: `${key} is required` }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } })
    }
  }

  if (String(body.password).length < 8) {
    return new Response(JSON.stringify({ error: 'Admin password must be at least 8 characters' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } })
  }

  const { data: authData, error: authError } = await adminClient.auth.admin.createUser({
    email: String(body.email).trim().toLowerCase(),
    password: String(body.password),
    email_confirm: true,
    user_metadata: { full_name: String(body.admin_name).trim(), role: 'school_admin' },
  })

  if (authError || !authData.user) {
    return new Response(JSON.stringify({ error: authError?.message ?? 'Could not create Auth account' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } })
  }

  const { data: schoolData, error: schoolError } = await adminClient.rpc('platform_create_school_internal', {
    p_name: String(body.name),
    p_admin_name: String(body.admin_name),
    p_email: String(body.email),
    p_phone: String(body.phone ?? ''),
    p_location: String(body.location ?? ''),
    p_subscription_plan: String(body.subscription_plan ?? 'Standard'),
    p_subscription_start: body.subscription_start,
    p_subscription_end: body.subscription_end,
    p_auth_user_id: authData.user.id,
  })

  if (schoolError) {
    await adminClient.auth.admin.deleteUser(authData.user.id)
    return new Response(JSON.stringify({ error: schoolError.message }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } })
  }

  return new Response(JSON.stringify(schoolData), { status: 200, headers: { ...cors, 'Content-Type': 'application/json' } })
})
